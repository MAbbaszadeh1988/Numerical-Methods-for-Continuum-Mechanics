function y = Foo(x)

y=x.^2;