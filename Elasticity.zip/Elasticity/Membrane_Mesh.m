function [ne,ng,p,c,efl,gfl] = Membrane(ndiv)
% MEMBRANE Generate triangular mesh for a rectangular membrane
%   Input:  ndiv - number of refinement levels (0 for coarse mesh)
%   Output: ne - number of elements
%           ng - number of nodes
%           p - node coordinates (ng x 2)
%           c - element connectivity (ne x 3)
%           efl - edge flags for each element vertex (ne x 3)
%           gfl - global edge flags for each node (ng x 1)
%
%   Domain: Rectangle from (-1,-1) to (1,1)

% Initialize coarse mesh (2 triangular elements covering the rectangle)
% Element 1: bottom-left triangle
x(1,1) = -1; y(1,1) = -1; efl(1,1) = 1;  % boundary edge 1 (bottom)
x(1,2) =  1; y(1,2) = -1; efl(1,2) = 1;  % boundary edge 1 (bottom)
x(1,3) = -1; y(1,3) =  1; efl(1,3) = 1;  % boundary edge 1 (left)

% Element 2: top-right triangle
x(2,1) =  1; y(2,1) = -1; efl(2,1) = 1;  % boundary edge 1 (bottom)
x(2,2) =  1; y(2,2) =  1; efl(2,2) = 1;  % boundary edge 1 (right)
x(2,3) = -1; y(2,3) =  1; efl(2,3) = 1;  % boundary edge 1 (top)

ne = 2;  % Start with 2 coarse elements

% Refinement loop (same as L-Shape)
if ndiv > 0
    for i = 1:ndiv
        nm = 0;  % count new elements
        
        for j = 1:ne  % loop over current elements
            % Compute midpoints of edges
            x(j,4) = 0.5 * (x(j,1) + x(j,2)); y(j,4) = 0.5 * (y(j,1) + y(j,2));
            x(j,5) = 0.5 * (x(j,2) + x(j,3)); y(j,5) = 0.5 * (y(j,2) + y(j,3));
            x(j,6) = 0.5 * (x(j,3) + x(j,1)); y(j,6) = 0.5 * (y(j,3) + y(j,1));
            
            % Initialize edge flags for new nodes
            efl(j,4) = 0; efl(j,5) = 0; efl(j,6) = 0;
            
            % Inherit edge flags from parent edges
            if (efl(j,1) == 1 && efl(j,2) == 1) efl(j,4) = 1; end
            if (efl(j,2) == 1 && efl(j,3) == 1) efl(j,5) = 1; end
            if (efl(j,3) == 1 && efl(j,1) == 1) efl(j,6) = 1; end
            
            % Create 4 sub-elements (same pattern as L-Shape)
            
            % First sub-element
            nm = nm + 1;
            xn(nm,1) = x(j,1); yn(nm,1) = y(j,1); efln(nm,1) = efl(j,1);
            xn(nm,2) = x(j,4); yn(nm,2) = y(j,4); efln(nm,2) = efl(j,4);
            xn(nm,3) = x(j,6); yn(nm,3) = y(j,6); efln(nm,3) = efl(j,6);
            
            % Second sub-element
            nm = nm + 1;
            xn(nm,1) = x(j,4); yn(nm,1) = y(j,4); efln(nm,1) = efl(j,4);
            xn(nm,2) = x(j,2); yn(nm,2) = y(j,2); efln(nm,2) = efl(j,2);
            xn(nm,3) = x(j,5); yn(nm,3) = y(j,5); efln(nm,3) = efl(j,5);
            
            % Third sub-element
            nm = nm + 1;
            xn(nm,1) = x(j,6); yn(nm,1) = y(j,6); efln(nm,1) = efl(j,6);
            xn(nm,2) = x(j,5); yn(nm,2) = y(j,5); efln(nm,2) = efl(j,5);
            xn(nm,3) = x(j,3); yn(nm,3) = y(j,3); efln(nm,3) = efl(j,3);
            
            % Fourth sub-element (center)
            nm = nm + 1;
            xn(nm,1) = x(j,4); yn(nm,1) = y(j,4); efln(nm,1) = efl(j,4);
            xn(nm,2) = x(j,5); yn(nm,2) = y(j,5); efln(nm,2) = efl(j,5);
            xn(nm,3) = x(j,6); yn(nm,3) = y(j,6); efln(nm,3) = efl(j,6);
        end
        
        ne = 4 * ne;  % Number of elements quadruples
        
        % Transfer to master arrays
        for k = 1:ne
            for l = 1:3
                x(k,l) = xn(k,l);
                y(k,l) = yn(k,l);
                efl(k,l) = efln(k,l);
            end
        end
    end
end

% Build node list and connectivity (same as L-Shape)
p(1,1) = x(1,1); p(1,2) = y(1,1); gfl(1,1) = efl(1,1);
p(2,1) = x(1,2); p(2,2) = y(1,2); gfl(2,1) = efl(1,2);
p(3,1) = x(1,3); p(3,2) = y(1,3); gfl(3,1) = efl(1,3);
c(1,1) = 1; c(1,2) = 2; c(1,3) = 3;

eps_val = 0.000001;
ng = 3;

for i = 2:ne
    for j = 1:3
        Iflag = 0;
        for k = 1:ng
            if (abs(x(i,j) - p(k,1)) < eps_val)
                if (abs(y(i,j) - p(k,2)) < eps_val)
                    Iflag = 1;
                    c(i,j) = k;
                end
            end
        end
        if (Iflag == 0)
            ng = ng + 1;
            p(ng,1) = x(i,j);
            p(ng,2) = y(i,j);
            gfl(ng,1) = efl(i,j);
            c(i,j) = ng;
        end
    end
end

% Plot the mesh (same as L-Shape)
figure;
hold on;
for i = 1:ne
    xp(1) = p(c(i,1),1); yp(1) = p(c(i,1),2);
    xp(2) = p(c(i,2),1); yp(2) = p(c(i,2),2);
    xp(3) = p(c(i,3),1); yp(3) = p(c(i,3),2);
    xp(4) = p(c(i,1),1); yp(4) = p(c(i,1),2);
    plot(xp, yp, 'r-o');
end
axis equal;
grid on;
title(sprintf('Membrane Mesh (ndiv=%d, ne=%d, ng=%d)', ndiv, ne, ng));
xlabel('X');
ylabel('Y');

end