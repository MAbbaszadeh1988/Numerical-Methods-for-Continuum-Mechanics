% function [ne,ng,p,c,efl,gfl] =trgl3_W(ndiv)
function [ne,ng,p,c,gfl] = trgl3_W(ndiv);
% clear all;
% clc
% ndiv=2;
% %   a=-0.2;
%=========================================================
%Triangulation of L shape domain into 3-node element
%by the successive subdivision of six ancestral element
%=========================================================

%---------------------------------------------------------
%ancestrsl structure with twelve elements
%---------------------------------------------------------
ne=18;
x(1,1)=0.8; y(1,1)=0.4; efl(1,1)=1;  %first element
x(1,2)=  1; y(1,2)=  1; efl(1,2)=2;
x(1,3)=0.8; y(1,3)=  1; efl(1,3)=3;

x(2,1)=0.8; y(2,1)=0.4; efl(2,1)=1;  %second element
x(2,2)=0.8; y(2,2)=  1; efl(2,2)=3;
x(2,3)=0.6; y(2,3)=0.4; efl(2,3)=3;

x(3,1)=0.6; y(3,1)=-0.2; efl(3,1)=1;  %third element
x(3,2)=0.8; y(3,2)= 0.4; efl(3,2)=1;
x(3,3)=0.6; y(3,3)= 0.4; efl(3,3)=3;

x(4,1)=0.6; y(4,1)=-0.2; efl(4,1)=1;  %fourth element
x(4,2)=0.6; y(4,2)=0.4;  efl(4,2)=3;
x(4,3)=0.4; y(4,3)=-0.2; efl(4,3)=3;

x(5,1)=0.4; y(5,1)=-0.8; efl(5,1)=1;  %five element
x(5,2)=0.6; y(5,2)=-0.2; efl(5,2)=1;
x(5,3)=0.4; y(5,3)=-0.2; efl(5,3)=3;

x(6,1)=0.4; y(6,1)=-0.8; efl(6,1)=1;  %six element
x(6,2)=0.4; y(6,2)=-0.2; efl(6,2)=3;
x(6,3)=0.2; y(6,3)=   0; efl(6,3)=1;

x(7,1)=0.4; y(7,1)=-0.2; efl(7,1)=1;  %six element
x(7,2)=0.2; y(7,2)= 0.4; efl(7,2)=1;
x(7,3)=0.2; y(7,3)=   0; efl(7,3)=3;

x(8,1)=0.2; y(8,1)=  0; efl(8,1)=1;  %six element
x(8,2)=0.2; y(8,2)=0.4; efl(8,2)=3;
x(8,3)=  0; y(8,3)=0.8; efl(8,3)=1;

x(9,1)=0.2; y(9,1)=0.4; efl(9,1)=1;  %six element
x(9,2)=  0; y(9,2)=  1; efl(9,2)=1;
x(9,3)=  0; y(9,3)=0.8; efl(9,3)=3;

% for i=1:9
%     for j=1:3
%         x(9+i,j)=-x(i,j);
%         y(9+i,j)=y(i,j);
%         efl(9+i,j)=efl(i,j);
%     end
% end
%

x(18,1)=-0.8; y(18,1)=0.4; efl(18,1)=1;  %first element
x(18,2)=-0.8; y(18,2)=  1; efl(18,2)=3;
x(18,3)=-1; y(18,3)=  1; efl(18,3)=2;

x(17,1)=-0.8; y(17,1)=0.4; efl(17,1)=3;  %second element
x(17,2)=-0.6; y(17,2)=0.4; efl(17,2)=1;
x(17,3)=-0.8; y(17,3)=1;  efl(17,3)=1;

x(16,1)=-0.6; y(16,1)=-0.2; efl(16,1)=1;  %third element
x(16,2)=-0.6; y(16,2)=0.4; efl(16,2)=3;
x(16,3)=-0.8; y(16,3)= 0.4; efl(16,3)=1;

x(15,1)=-0.6; y(15,1)=-0.2; efl(15,1)=3;  %fourth element
x(15,2)=-0.4; y(15,2)=-0.2;  efl(15,2)=1;
x(15,3)=-0.6; y(15,3)=0.4; efl(15,3)=1;

x(14,1)=-0.4; y(14,1)=-0.8; efl(14,1)=1;  %five element
x(14,2)=-0.4; y(14,2)=-0.2; efl(14,2)=3;
x(14,3)=-0.6; y(14,3)=-0.2; efl(14,3)=1;

x(13,1)=-0.4; y(13,1)=-0.8; efl(13,1)=1;  %six element
x(13,2)=-0.2; y(13,2)=0; efl(13,2)=1;
x(13,3)=-0.4; y(13,3)=-0.2; efl(13,3)=3;

x(12,1)=-0.4; y(12,1)=-0.2; efl(12,1)=1;  %six element
x(12,2)=-0.2; y(12,2)= 0; efl(12,2)=3;
x(12,3)=-0.2; y(12,3)= 0.4; efl(12,3)=1;

x(11,1)=-0.2; y(11,1)=  0; efl(11,1)=1;  %six element
x(11,2)= 0; y(11,2)=0.8; efl(11,2)=1;
x(11,3)= -0.2; y(11,3)=0.4; efl(11,3)=3;

x(10,1)=-0.2; y(10,1)=0.4; efl(10,1)=1;  %six element
x(10,2)=   0; y(10,2)=0.8; efl(10,2)=3;
x(10,3)=   0; y(10,3)=  1; efl(10,3)=1;



if ndiv>0
    for i=1:ndiv
        nm=0; %count the new element arising by each refinment loop
              %four element will be generated in each pass   
        for j=1:ne  % loop over current element 
            %assign vertex nodes to sub-elements
            %these will become the 'new' element
            x(j,4)=0.5*(x(j,1)+x(j,2)); y(j,4)=0.5*(y(j,1)+y(j,2));
            x(j,5)=0.5*(x(j,2)+x(j,3)); y(j,5)=0.5*(y(j,2)+y(j,3));
            x(j,6)=0.5*(x(j,3)+x(j,1)); y(j,6)=0.5*(y(j,3)+y(j,1));
            
            efl(j,4)=0;  efl(j,5)=0;  efl(j,6)=0;
            
            if (efl(j,1)==1 && efl(j,2)==1) efl(j,4)=1; end
            if (efl(j,2)==1 && efl(j,3)==1) efl(j,5)=1; end
            if (efl(j,3)==1 && efl(j,1)==1) efl(j,6)=1; end
            
            if (efl(j,1)==2 && efl(j,2)==2) efl(j,4)=2; end
            if (efl(j,2)==2 && efl(j,3)==2) efl(j,5)=2; end
            if (efl(j,3)==2 && efl(j,1)==2) efl(j,6)=2; end
            
            if (efl(j,1)==3 && efl(j,2)==3) efl(j,4)=3; end
            if (efl(j,2)==3 && efl(j,3)==3) efl(j,5)=3; end
            if (efl(j,3)==3 && efl(j,1)==3) efl(j,6)=3; end
            
            if (efl(j,1)==1 && efl(j,2)==2) efl(j,4)=1; end
            
            if (efl(j,2)==2 && efl(j,3)==3) efl(j,5)=3; end
            
            if (efl(j,1)==1 && efl(j,3)==2) efl(j,6)=1; end
            
            if (efl(j,2)==3 && efl(j,3)==2) efl(j,5)=3; end
            
%             if (efl(j,1)==3 && efl(j,3)==2) efl(j,6)=2; end
%            
%             if (efl(j,1)==3 && efl(j,2)==2) efl(j,4)=2; end
%             
%             if (efl(j,1)==3 && efl(j,2)==1) efl(j,4)=1; end
%             
%             if (efl(j,1)==3 && efl(j,3)==1) efl(j,6)=1; end
                                  
            nm=nm+1;   %first sub element
            
            xn(nm,1)=x(j,1); yn(nm,1)=y(j,1); efln(nm,1)=efl(j,1);
            xn(nm,2)=x(j,4); yn(nm,2)=y(j,4); efln(nm,2)=efl(j,4);
            xn(nm,3)=x(j,6); yn(nm,3)=y(j,6); efln(nm,3)=efl(j,6);
            
            nm=nm+1;    %second sub-element
            
            xn(nm,1)=x(j,4); yn(nm,1)=y(j,4); efln(nm,1)=efl(j,4);
            xn(nm,2)=x(j,2); yn(nm,2)=y(j,2); efln(nm,2)=efl(j,2);
            xn(nm,3)=x(j,5); yn(nm,3)=y(j,5); efln(nm,3)=efl(j,5);
            
            
            nm=nm+1;   %third sub-elemen
            
            xn(nm,1)=x(j,6); yn(nm,1)=y(j,6); efln(nm,1)=efl(j,6);
            xn(nm,2)=x(j,5); yn(nm,2)=y(j,5); efln(nm,2)=efl(j,5);
            xn(nm,3)=x(j,3); yn(nm,3)=y(j,3); efln(nm,3)=efl(j,3);
         
            
            nm=nm+1;   %fourth sub-elemen
            
            xn(nm,1)=x(j,4); yn(nm,1)=y(j,4); efln(nm,1)=efl(j,4);
            xn(nm,2)=x(j,5); yn(nm,2)=y(j,5); efln(nm,2)=efl(j,5);
            xn(nm,3)=x(j,6); yn(nm,3)=y(j,6); efln(nm,3)=efl(j,6);
          
        end  % end of loop over current element
        
        ne=4*ne;  % number of element has increased
                  % by a factor of four
                  
        for k=1:ne  % relable the new points and put them in the master list
                    % project boundary nodes onto the circle   
           for l=1:3
               x(k,l)=xn(k,l);   y(k,l)=yn(k,l);   efl(k,l)=efln(k,l);
               
               
           end
        end
    end % end do of refinment loop
end  % end if of refinment loop
    
% 6 nodes of the first element are entered manually

p(1,1)=x(1,1); p(1,2)=y(1,1); gfl(1,1)=efl(1,1);
p(2,1)=x(1,2); p(2,2)=y(1,2); gfl(2,1)=efl(1,2);
p(3,1)=x(1,3); p(3,2)=y(1,3); gfl(3,1)=efl(1,3);

c(1,1)=1; c(1,2)=2; c(1,3)=3;
eps=0.000001; ng=3;

for i=2:ne
    for j=1:3
        Iflag=0;
        for k=1:ng
            if (abs(x(i,j)-p(k,1))<eps) 
                if (abs(y(i,j)-p(k,2))<eps)
                    Iflag=1;
                    c(i,j)=k;
                end
            end
        end
        if (Iflag==0)
            ng=ng+1;
            p(ng,1)=x(i,j);
            p(ng,2)=y(i,j);
            gfl(ng,1)=efl(i,j);
            c(i,j)=ng;
        end
    end
end
%  fo

% 6 nodes of the first element are entered manually


%  for i=1:ne
%      xp(1)=x(i,1); xp(2)=x(i,2); xp(3)=x(i,3); xp(4)=x(i,1);
%      yp(1)=y(i,1); yp(2)=y(i,2); yp(3)=y(i,3); yp(4)=y(i,1);
%      xp';
%      yp';
%      plot(xp,yp,'-bo');hold on
%  end

% for i=1:ne
%     xp(1)=p(c(i,1),1); yp(1)=p(c(i,1),2);
%     xp(2)=p(c(i,2),1); yp(2)=p(c(i,2),2);
%     xp(3)=p(c(i,3),1); yp(3)=p(c(i,3),2);
%     xp(4)=p(c(i,1),1); yp(4)=p(c(i,1),2);
%     plot(xp,yp);hold on
% end
%trimesh(c,p(:,1),p(:,2),zeros(ng,1))

end