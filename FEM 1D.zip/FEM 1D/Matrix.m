function [M,D] = Matrix (xe)
ne = length(xe)-1;
for l=1:ne
    h(l) = xe(l+1)-xe(l);
end

D = zeros(ne+1);
M = zeros(ne+1);

for i=1:ne+1
    for j=1:ne+1
        if (i==1 && j==1) 
            D(i,j) = 1/h(i);
            M(i,j) = h(i)/3;
        elseif (i==j && i~=1 && i~=ne+1)
            D(i,j) = 1/h(i-1)+1/h(i);
            M(i,j) = h(i-1)/3+h(i)/3;
        elseif (i==ne+1 && j==ne+1)
            D(i,j) = 1/h(ne);
            M(i,j) = h(ne)/3;
        elseif (j==i+1)
            D(i,j) = -1/h(i);
            M(i,j) = h(i)/6;
        elseif (j==i-1)
            D(i,j) = -1/h(i-1);
            M(i,j) = h(i-1)/6;
        else
            D(i,j) = 0;
            M(i,j) = 0;
        end
    end
end
D = sparse(D);
M = sparse(M);
return;