%------ Two-Dimensional linear elasticity
% Example 1: L-Shape problem
%---------------------------------------
% Elastic constants
E=1e5; nu=0.3;
lam=E*nu/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu));
%
Penalty=10^20;
% Mesh
load lshape231 p t ibcd
n=size(p,2); nn=2*n;
% Exact solution
ue=zeros(nn,1);
[th,r]=cart2pol(p(1,:),p(2,:));
alpha=0.544483737; omg=3*pi/4; ralpha=r.^alpha/(2*mu);
C2=2*(lam+2*mu)/(lam+mu); C1=-cos((alpha+1)*omg)/cos((alpha-1)*omg);
ur=ralpha.*(-(alpha+1)*cos((alpha+1)*th)+(C2-alpha-1)*C1*cos((alpha-1)*th));
ut=ralpha.*( (alpha+1)*sin((alpha+1)*th)+(C2+alpha-1)*C1*sin((alpha-1)*th));
ue(1:2:end)=ur.*cos(th)-ut.*sin(th);
ue(2:2:end)=ur.*sin(th)+ut.*cos(th);
% Boundary conditions
nnb=2*length(ibcd);
ibc=zeros(nnb,1); ibc(1:2:end)=2*ibcd-1; ibc(2:2:end)=2*ibcd;
ubc=zeros(nnb,1); ubc(1:2:end)=ue(2*ibcd-1); ubc(2:2:end)=ue(2*ibcd);
% Assembly of the Stiffness matrix
K=elas2dmat1(p,t,E,nu);
% Right-hand side
f=zeros(nn,1);
% Penalization of Stiffness matrix and right-hand sides
K(ibc,ibc)=K(ibc,ibc)+Penalty*speye(nnb);
f(ibc)=Penalty*ubc;
% Solution by Gaussian elimination
u=K\f;
% Shear energy density & Von Mises effective stress
[Sh,Vms]=elas2dsvms(p,t,u,E,nu);
% Show the deformed mesh and shear energy density
elas2dshow(p,t,u,3000,Sh)