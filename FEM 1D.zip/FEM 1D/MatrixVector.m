function [M,D] = MatrixVector(xe)
ne = length(xe) - 1;
h = xe(2:end) - xe(1:end-1);  % Vectorized computation of h

% Preallocate sparse matrices
D = sparse(ne+1, ne+1);
M = sparse(ne+1, ne+1);

% Set diagonal entries
% First row (i=1, j=1)
D(1,1) = 1/h(1);
M(1,1) = h(1)/3;

% Last row (i=ne+1, j=ne+1)
D(ne+1, ne+1) = 1/h(ne);
M(ne+1, ne+1) = h(ne)/3;

% Interior diagonal entries (i=j, i=2:ne)
if ne >= 2
    idx = 2:ne;
    D(sub2ind(size(D), idx, idx)) = 1./h(idx-1) + 1./h(idx);
    M(sub2ind(size(M), idx, idx)) = h(idx-1)/3 + h(idx)/3;
end

% Set off-diagonal entries (j = i+1)
idx_super = 1:ne;
D(sub2ind(size(D), idx_super, idx_super+1)) = -1./h(idx_super);
M(sub2ind(size(M), idx_super, idx_super+1)) = h(idx_super)/6;

% Set off-diagonal entries (j = i-1)
idx_sub = 2:ne+1;
D(sub2ind(size(D), idx_sub, idx_sub-1)) = -1./h(idx_sub-1);
M(sub2ind(size(M), idx_sub, idx_sub-1)) = h(idx_sub-1)/6;

% No need to explicitly set zeros as sparse matrices already have zeros

return;