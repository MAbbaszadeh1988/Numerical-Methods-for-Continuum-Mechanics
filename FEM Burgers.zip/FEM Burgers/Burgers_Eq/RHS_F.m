function [F]=RHS_F(func,t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function calculates time dependent F matrix by
% 3 point Gaussian Quadrature
%
% Function inputs:
%
% func : RHS function name (string)
% t : current time
%
% Function outputs:
% F : Inner product of func and PLBF at t
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global n h

xweights = [5/9;8/9;5/9];

F=zeros (n,1);
for i=1:n
    xi=h*(i-1);
    xf=xi+h;
    xnodes = gaussnodes(xi,xf);
    f = feval(func,xnodes,t);
    F(i)=(f.*(1/h*(xnodes-xi)))*xweights*h/2;
    
    
    xi=h*(i);
    xf=xi+h;
    xnodes = gaussnodes(xi,xf);
    f = feval(func,xnodes,t);
    F(i)=F(i)+(f.*(1/h*(xf-xnodes)))*xweights*h/2;
    
    
end