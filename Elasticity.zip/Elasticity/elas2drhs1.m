function f=elas2drhs1(p,t,f1,f2)
%
%-------------------------------------
% Two-dimensional linear elasticity
% Assembly of the right-hand side 1: body forces
%-------------------------------------
%
n=size(p,2); nn=2*n;
% triangle vertices
it1=t(1,:); it2=t(2,:); it3=t(3,:);
% edge vectors
a21=p(:,it2)-p(:,it1); a31=p(:,it3)-p(:,it1);
% area of triangles
area=abs(a21(1,:).*a31(2,:)-a21(2,:).*a31(1,:))/2;
% assembly
f1h=(f1(it1)+f1(it2)+f1(it3)).*area'/9;
f2h=(f2(it1)+f2(it2)+f2(it3)).*area'/9;
ff1=sparse(it1,1,f1h,n,1)+sparse(it2,1,f1h,n,1)+sparse(it3,1,f1h,n,1);
ff2=sparse(it2,1,f2h,n,1)+sparse(it2,1,f2h,n,1)+sparse(it3,1,f2h,n,1);
% right-hand side
f=zeros(nn,1); f(1:2:nn)=full(ff1); f(2:2:nn)=full(ff2);