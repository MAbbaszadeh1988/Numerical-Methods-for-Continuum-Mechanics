function elas2dshow(p,t,u,magnify,sf)
%
%-------------------------------------
% Two-dimensional linear elasticity
% Visualization
%-------------------------------------
%
np=size(p,2);
uu=reshape(u,2,np)';
pu=p(1:2,:)'+magnify*uu;
colormap(1-gray)
trisurf(t(1:3,:)',pu(:,1),pu(:,2),zeros(np,1),sf,'facecolor','interp')
view(2)