function K=elas2dmat2(p,t,Young,nu)
%---------------------------------------------------------------
% Two-dimensional finite element method for the Lame Problem
% Assembly of the stiffness matrix
%---------------------------------------------------------------
n=size(p,2); nn=2*n;
%
% Lame constants
lam=Young*nu/((1+nu)*(1-2*nu)); 
mu=.5*Young/(1+nu);
%
% area of triangles
it1=t(1,:); it2=t(2,:); it3=t(3,:);
x21=(p(1,it2)-p(1,it1))'; x32=(p(1,it3)-p(1,it2))'; x31=(p(1,it3)-p(1,it1))';
y21=(p(2,it2)-p(2,it1))'; y32=(p(2,it3)-p(2,it2))'; y31=(p(2,it3)-p(2,it1))';
ar=.5*(x21.*y31-x31.*y21);
muh=mu./(4*ar); lamh=lam./(4*ar); lamuh=(lam+2*mu)./(4*ar);
clear it1 it2 it3
%
x=[ x32 -x31 x21]; y=[-y32 y31 -y21];
it1=2*t'-1; 
it2=2*t';
% Assembly
K=sparse(nn,nn);
for i=1:3
    for j=1:3
        K=K+sparse(it1(:,i),it2(:,j),lamh.*y(:,i).*x(:,j)+muh.*x(:,i).*y(:,j),nn,nn);
        K=K+sparse(it2(:,j),it1(:,i),lamh.*y(:,i).*x(:,j)+muh.*x(:,i).*y(:,j),nn,nn);
        K=K+sparse(it1(:,i),it1(:,j),lamuh.*y(:,i).*y(:,j)+muh.*x(:,i).*x(:,j),nn,nn);
        K=K+sparse(it2(:,i),it2(:,j),lamuh.*x(:,i).*x(:,j)+muh.*y(:,i).*y(:,j),nn,nn);
    end
end