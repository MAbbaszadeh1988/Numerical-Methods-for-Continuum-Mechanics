function [g] = g_func(x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial Condition Function for Burgers' Equation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global q

%For u(t,x)=e�?t*sin(pi*x)
%g = sin(pi*x);

%For u(t,x)=e�?t*sin(pi*x)*q�2
%g = sin(pi*x)*q�2;

%Square Wave Input
%%f
for i=1:length(x)
    if x(i)<= (1/4)
        g(i) = 1;
    else
        g(i) = 0;
    end
end
%g