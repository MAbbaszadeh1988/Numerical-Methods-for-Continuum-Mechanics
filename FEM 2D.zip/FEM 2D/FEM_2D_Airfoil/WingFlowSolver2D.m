clear
clc
g = Airfoilg();
[p,e,t] = initmesh(g,'hmax',0.5);
A = StiffnessAssembler2D(p,t,inline('1','x','y'));
[R,r] = RobinAssembler2D(p,e,@Kappa1,@gD1,@gN1);
phi = (A+R)\r;
figure, pdeplot(p,e,t,'XYData',phi)

[phix,phiy] = pdegrad(p,t,phi); % derivatives of ’phi’
u = -phix';
v = -phiy';
figure, pdeplot(p,e,t,'flowdata',[u v])