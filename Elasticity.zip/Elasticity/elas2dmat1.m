function A=elas2dmat1(p,t,Young,nu)
%---------------------------------------------------------------
% Two-dimensional linear elasticity
% Assembly of the stiffness matrix
%---------------------------------------------------------------
n=size(p,2); nt=size(t,2); nn=2*n;
% Lame constants
lam=Young*nu/((1+nu)*(1-2*nu)); mu=.5*Young/(1+nu);
% Constant matrices
C=mu*[2,0,0;0,2,0;0,0,1]+lam*[1,1,0;1,1,0;0,0,0];
Zh=[zeros(1,2);eye(2)];
% Loop over all triangles
A=sparse(nn,nn);
for ih=1:nt
    it=t(1:3,ih);
    itt=2*t([1,1,2,2,3,3],ih)-[1;0;1;0;1;0];
    xy=zeros(3,2); xy(:,1)=p(1,it)'; xy(:,2)=p(2,it)';
    D=[1,1,1;xy'];
    gradphi=D\Zh;
    R=zeros(3,6);
    R([1,3],[1,3,5])=gradphi';
    R([3,2],[2,4,6])=gradphi';
    A(itt,itt)=A(itt,itt)+0.5*det(D)*R'*C*R;
end