clear
clc
close all
g=Rectg(0,0,1,1);
[p,e,t]=initmesh(g,'hmax',0.05); % create mesh

xi=1+zeros(size(p,2),1); % initial zero guess
maxIter = 10;
d_norm = zeros(maxIter,1);
r_norm = zeros(maxIter,1);
% a(u) = Afcn;
% f(x,y) = Ffcn;
for k = 1:maxIter
    [J,r] = JacResAssembler2D(p,e,t,xi,@Afcn,@Ffcn);
    d = J\r;
    xi = xi + d;

    d_norm(k) = norm(d);
    r_norm(k) = norm(r);
end
figure, pdeplot(p,e,t,'XYData',xi)
figure, pdeplot(p,e,t,'XYData',xi,'ZData',xi)

 T = table((1:maxIter)', d_norm, r_norm, ...
    'VariableNames', {'Iteration','Norm_d','Norm_r'});
 disp(T)
