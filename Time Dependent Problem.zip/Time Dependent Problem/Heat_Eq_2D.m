clear all; clc
time=clock;
%%
ndiv=4;  %discretization level
T=1; M=1000; tau=T/M;
[ne,ng,p,c,efl,gfl]=trgl3_delaunay_sqr(40,40);

C=zeros(M+1,ng);
u = @(x,y,t) exp(t)*sin(pi.*x).*sin(pi.*y);
f = @(x,y,t) (1+2*pi^2)*exp(t)*sin(pi.*x).*sin(pi.*y);  % Source term

%% Initialize at t=0
% for i=1:ng
%     C(1,i) = u(p(i,1), p(i,2), 0);
% end
 C(1,:) = u(p(:,1), p(:,2), 0);


%----------------------------------------------
% Assemble global matrices
%----------------------------------------------
gdm=zeros(ng,ng); % Global Diffuse Matrix
gmm=zeros(ng,ng); % Global Mass Matrix

for l=1:ne
    j=c(l,1); x1=p(j,1); y1=p(j,2);
    j=c(l,2); x2=p(j,1); y2=p(j,2);
    j=c(l,3); x3=p(j,1); y3=p(j,2);
    
    edm_elm=edm3(x1,y1,x2,y2,x3,y3);
    emm_elm=eam3(x1,y1,x2,y2,x3,y3);
    
    for i=1:3
        i1=c(l,i);
        for j=1:3
            j1=c(l,j);
            gdm(i1,j1)=gdm(i1,j1)+edm_elm(i,j);
            gmm(i1,j1)=gmm(i1,j1)+emm_elm(i,j);
        end
    end
end

% Time stepping
for n=0:M-1
    fprintf('t = %f\n', n*tau);
    
    t_mid = (n+0.5)*tau;
    t_new = (n+1)*tau;
    
    % Assemble system matrix (Crank-Nicolson)
    A = gmm + (tau/2)*gdm;  % Use tau/2 for Crank-Nicolson
    B = gmm - (tau/2)*gdm;
    % Compute RHS
    f_vec = f(p(:,1), p(:,2), t_mid);

    b = B * C(n+1,:)' + tau * gmm * f_vec;
    
    % Apply Dirichlet boundary conditions
    for j=1:ng
        if (gfl(j,1)==1 || gfl(j,1)==2 || gfl(j,1)==3)
            for i=1:ng
                b(i) = b(i) - A(i,j) * u(p(j,1), p(j,2), t_new);
                A(i,j) = 0;
                A(j,i) = 0;
            end
            A(j,j) = 1;
            b(j) = u(p(j,1), p(j,2), t_new);
        end
    end
    
    % Solve system
    C(n+2,:) = A\b;
end

%% Error analysis
P = u(p(:,1), p(:,2), T);
error = P' - C(end,:);

fprintf('Maximum error: %e\n', norm(error, inf));
fprintf('RMS error: %e\n', sqrt(mean(error.^2)));

% Plot solution
figure, trisurf(c, p(:,1), p(:,2), C(end,:));
figure, trisurf(c, p(:,1), p(:,2), P' - C(end,:));
title('Exact solution at T=1');