clear all; 
clc;
close all
%%
a = 0; b = 1;
eps = 1e-3;
dt = 1e-4; T = 1; Mt = T/dt;
N = 2000; h = (b-a)/N;

% Random mesh
x = zeros(N+1,1);
x(2:N+1) = sort(rand(N,1));
x(1) = 0; x(N+1) = 1;

% Mass and stiffness matrices (from your Matrix function)
[M, D] = Matrix(x);

% Nonlinear convection matrix (B is same as in your code)
B = gallery('tridiag', N+1, -0.5, 0, 0.5);
B(1,1) = -0.5;

% Initial condition
C = sin(2*pi*x) + 0.5*sin(pi*x);

% Time loop
for n = 1:Mt
    fprintf('t = %.4f\n', n*dt);
    
    U = C; % initial guess for Newton
    
    % Newton iteration
    max_iter = 50;
    tol = 1e-10;
    for iter = 1:max_iter
        
        % Residual F(U)
        F = M*U + dt * (B*(U.^2) + eps*D*U) - M*C;
        
        % Apply Dirichlet BCs (u=0 at boundaries)
        F(1) = 0;
        F(end) = 0;
        
        % Jacobian J = M + dt*(2*B*diag(U) + eps*D)
        J = M + dt * (2*B*spdiags(U,0,N+1,N+1) + eps*D);
        
        % Apply BCs to Jacobian
        J(1,:) = 0; J(1,1) = 1;
        J(end,:) = 0; J(end,end) = 1;
        
        % Solve J * dU = -F
        dU = J \ (-F);
        
        % Update
        U = U + dU;
        
        % Check convergence
        if norm(dU, inf) < tol
            fprintf('  Newton converged in %d iterations\n', iter);
            break;
        end
    end
    
    C = U; % update for next time step
    
    % Plot
    plot(x, C);
    drawnow;
end

hold on;
plot(x, C, 'r');
axis([0 1.1 -0.1 0.5]);