clear all
clc
tic
u = @(x) sin(x);
f = @(x) 2.*sin(x);
a = 0;
b = 1;
N = 10;
h = (b-a)/N;
x=(a:h:b)';
%%
%[M,D] = Matrix (x); % assembly of mass matrix
%[M,D] = MatrixVector(x);
%%
% D = (1/h).* gallery ('tridiag',N+1 , -1 ,2 , -1);
% D(1 ,1) = 1/h; D(N+1,N+1) = 1/h;
% M = (h/6) .* gallery ('tridiag',N+1 ,+1 ,4 ,+1);
% M(1 ,1) = h/3; M(N+1,N+1) = h/3;
%%
n = N + 1;

% D matrix
e = ones(n,1);
D = (1/h) * (diag(2*e) + diag(-e(1:end-1),1) + diag(-e(1:end-1),-1));
D(1,1) = 1/h;
D(n,n) = 1/h;

% M matrix
M = (h/6) * (diag(4*e) + diag(e(1:end-1),1) + diag(e(1:end-1),-1));
M(1,1) = h/3;
M(n,n) = h/3;
%%
I = eye(size(M));
S = D+M;
S(1 ,:) = I(1 ,:);
S(end ,:) = I(end ,:);
 
F = M*f(x);
F(1) = u(a);
F(end) = u(b);
U = S\F;
norm (U-u(x),inf)
plot(x,U,x,u(x),'o')