function f = rhs(points)
% Evaluate the right hand side function of the PDE.
% The matrix ‘points‘ contains one point on each row.
x = points(:, 1); y = points(:, 2);
f = 15 * sin(pi * x) * sin(pi * y);
end