function [F]=GQ_three(func)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function calculates matrix from inner product with basis by
% 3 point Gaussian Quadrature
%
% **ASSUMES zero boundary conditions!!**
%
%
% Function inputs:
%
% func : Initial function (x) name (type string)
%
% Function outputs:
% F : Inner product of func and PLBF
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global n h

F=zeros (n,1);

xweights = [5/9;8/9;5/9];
for i=1:n 

xi=h*(i-1);
xf=xi+h;
xnodes = gaussnodes(xi,xf);
temp = feval(func,xnodes);

F(i)=(temp.*(1/h*(xnodes-xi)))*xweights*h/2;

xi=h*(i);
xf=xi+h;
xnodes = gaussnodes(xi,xf);
temp = feval(func,xnodes);

F(i)=F(i)+(temp.*(1/h*(xf-xnodes)))*xweights*h/2;

end