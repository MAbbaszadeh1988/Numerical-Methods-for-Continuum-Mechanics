function [ftxy]=FEM_Burgers_func(in_t,in_y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function calculates the derivative of Burgers' equation
% and the sensitivity equation.
%
% Function inputs:
%
% in t : current time
% in y : current y
%
%
% Function outputs:
% out y : computed derivative
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global M B q C f;

F = RHS_F(f, in_t);

ftxy = M\(F-(1/2)*B*in_y.^2-q*C*in_y);