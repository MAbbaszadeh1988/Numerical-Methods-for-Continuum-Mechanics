clear all
clc
global n h m q B C M y g 
n = 32;
final_t = 2;
m = 200;
Re = 100;
q = 1/Re;
n = n-1;
h = 1/(n+1);
x = 0:h:1;
solver = 'ode45';
option = odeset('RelTol',1e-6,'AbsTol',1e-10);
B = (1/h).*gallery('tridiag',n,-1/2,0,-1/2);
M = (h/6).*gallery('tridiag',n,+1,4,+1);
C = (1/h).*gallery('tridiag',n,-1,2,-1);
g = 'g_func';
f = 'f_func';
G = GQ_three(g);
init_y = M\G;
t = 0:final_t/m:final_t;
timeODEint = tic;

F = RHS_F(f, t);
ftxy = M\(F-(1/2)*B*init_y.^2-q*C*init_y);
[t,y] = ode45(ftxy,t,init_y);

% [t,y] = feval('ode45','FEM_Burgers_func',t,init_y);
timeODEfinal = toc;
y = y';
tempy=[zeros(1,length(t));y;zeros(1,length(t))];
mesh(x,t,tempy');