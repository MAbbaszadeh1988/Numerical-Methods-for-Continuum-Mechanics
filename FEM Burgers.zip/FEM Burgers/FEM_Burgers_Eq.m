clear all
clc
a = 0;  b = 1;
eps = 1e-3;
dt = 1e-4;   T = 1;    Mt = T/dt;
N = 2000;  h = (b-a)/N;
% x = a:h:b;       x = x';
x = zeros(N+1,1);
x(2:N+1) = sort(rand(N,1));
x(1) = 0;      x(N+1) = 1;
[M,D] = Matrix (x);
%=========================================
B = gallery('tridiag',N+1,-0.5,0,0.5);
B(1,1) = -0.5;
%=========================================
C = sin(2.*pi.*x) + 0.5.*sin(pi.*x);
A = M+eps*dt.*D;
%=========================================
I = eye(size(A));
A(1,:) = I(1,:); 
A(end,:) = I(end,:);   

for n=1:Mt
    n*dt
    F = M*C - dt*B*(C.^2);
    F(1) = 0;   F(end) = 0;
    C = A\F;
    plot(x,C), drawnow
end
hold on
plot(x,C,'r'),   axis([0 1.1 -0.1 .5])