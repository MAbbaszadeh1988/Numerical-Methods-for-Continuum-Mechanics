%-------------------------------------------------------
clear all
clc
close all
format shorte
%-------------------------------------------------------
clear all;
%%
Vx=1.0; Vy=1.0;
%%
nref = 4;
% [ne,np,p,conn,gbc] = gen_p1grid(nref);
[ne,np,p,conn,gbc] = trgl3_W(nref);

% plot the mesh to see if it is right
figure(1);
trimesh(conn,p(:,1),p(:,2));
pause(2);
%%
for i=1:np
    u_ex(i)=feval(@EXACT,p(i,1),p(i,2));
    if(gbc(i,1)==1 || gbc(i,1)==2 || gbc(i,1)==3)
        gbc(i,2) = u_ex(i);
    end
end
%%
Ag = zeros(np,np); % Stiff Matrix A+B+M=Ag
b = zeros(np,1);
%%
for l=1:ne
    j=conn(l,1); x1=p(j,1); y1=p(j,2);
    j=conn(l,2); x2=p(j,1); y2=p(j,2);
    j=conn(l,3); x3=p(j,1); y3=p(j,2); 
    % compute local element matrices
    [elmA] = locA(x1,y1,x2,y2,x3,y3);
    [elmB] = locB(Vx,Vy,x1,y1,x2,y2,x3,y3);
    [elmM] = locM(x1,y1,x2,y2,x3,y3);
    for i=1:3
        i1 = conn(l,i);
        for j=1:3
            j1 = conn(l,j);
            % Global Matrix
            Ag(i1,j1) = Ag(i1,j1) + elmA(i,j) + elmB(i,j);
            % RHS
            b(i1) = b(i1) + elmM(i,j)*feval(@SRC,p(j1,1),p(j1,2));
        end
    end
end
%%
for m=1:np
    if(gbc(m,1)==1 || gbc(m,1)==2 || gbc(m,1)==3)
        for i=1:np
            b(i) = b(i) - Ag(i,m) * gbc(m,2);
            Ag(i,m) = 0; Ag(m,i) = 0;
        end
        Ag(m,m) = 1.0; 
        b(m) = gbc(m,2);
    end
end
%%
u_fem=Ag\b;
%%
figure(2);
trisurf(conn,p(:,1),p(:,2),u_fem);
% compare with exact solution
disp('max err='), max(abs(u_fem-u_ex')),