function [f] = f func(x,t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Forcing Function for Burgers Equation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global q

f = 0;
%Exact solution test ? for u(t,x) = h(t) * phi(x) * r(q), need f of form
%%% f = h t(t)*phi(x)*r(q)+(h(t)*r(q))�2*phi(x)*phi'(x)?q*h(t)*r(q)*phi''(x)

%For u(t,x)=e�?t*sin(pi*x)
%f = (?exp(?t)*sin(pi*x))+ exp(?2*t)*sin(pi*x)*pi.*cos(pi*x) ? ...
%q*exp(?t)*(?1*pi�2*sin(pi*x));

%For u(t,x)=e�?t*sin(pi*x)*q�2
%f = ?q�2*exp(?t).*sin(pi*x) + pi�2*q�3*exp(?t).*sin(pi*x) + ...
%pi*q�4*exp(?2*t).*cos(pi*x).*sin(pi*x);