function g = boundary_condition(points)
% Evaluate the boundary condition of the PDE.
% The matrix ‘points‘ contains one point on each row.
x = points(:, 1); y = points(:, 2);
g = (1 - x) .* y .* sin(pi * x);
end