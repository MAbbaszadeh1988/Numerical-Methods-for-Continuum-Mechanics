function L2Projector1D()
clc
clear
n = 20; % number of subintervals
h = 1/n; % mesh size
x = 0:h:1; % mesh
[M,~] = Matrix (x); % assembly of mass matrix
b = LoadVec1D (x, @Foo ); % assembly of load matrix
Pf = M\b; % solve linear system
plot (x,Pf)
end