function [x] = gaussnodes(xi,xf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes the three gauss points on interval [xi,xf]
%
% xi : initial x value
% xf : final x value
%
% Outputs

% x : vector of three GQ points
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Three nodes%
t(1) = -sqrt(3/5);
t(2) = 0;
t(3) = sqrt(3/5);


for i=1:3
x(i) = (xf-xi)/2*t(i)+(xf+xi)/2;
end