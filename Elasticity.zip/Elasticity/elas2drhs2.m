function g=elas2drhs2(p,ineum,g1,g2)
%
%-----------------------------------------------------
% Two-dimensional linear elasticity
% Assembly of the right-hand side 2: Neumann condition
%-----------------------------------------------------
%
n=size(p,2); nn=2*n;
%
ie1=ineum(1,:); ie2=ineum(2,:);
ibcn=union(ie1,ie2);
ne=length(ibcn);
% edge lengths
exy=p(:,ie2)-p(:,ie1);
le=sqrt(sum(exy.^2,1));
% g1,g2 at the center of mass
g1h=(g1(ie1)+g1(ie2)).*le/4;
g2h=(g2(ie1)+g2(ie2)).*le/4;
% assembly
gg1=sparse(ne,1);
gg1=sparse(ie1,1,g1h,ne,1)+sparse(ie2,1,g1h,ne,1);
gg2=sparse(ne,1);
gg2=sparse(ie1,1,g2h,ne,1)+sparse(ie2,1,g2h,ne,1);
% right-hand side
g=zeros(nn,1);
g(2*ibcn-1)=full(gg1);
g(2*ibcn) =full(gg2);