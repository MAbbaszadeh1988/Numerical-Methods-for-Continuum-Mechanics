function [ne,ng,p,c,efl,gfl] =L_Shape(ndiv)
% clear all;
% clc
% ndiv=2;
a=0;
%=========================================================

%---------------------------------------------------------
ne=6;
x(1,1)=a; y(1,1)=-1; efl(1,1)=3;  %first element
x(1,2)=1; y(1,2)=-1; efl(1,2)=1;
x(1,3)=a; y(1,3)=a; efl(1,3)=2;

x(2,1)=1; y(2,1)=-1; efl(2,1)=1;  %second element
x(2,2)=1; y(2,2)= a; efl(2,2)=1;
x(2,3)=a; y(2,3)= a; efl(2,3)=2;

x(3,1)=a; y(3,1)=a; efl(3,1)=2;  %third element
x(3,2)=1; y(3,2)=a; efl(3,2)=1;
x(3,3)=1; y(3,3)=1; efl(3,3)=1;

x(4,1)=a; y(4,1)=a; efl(4,1)=2;  %fourth element
x(4,2)=1; y(4,2)=1; efl(4,2)=1;
x(4,3)=a; y(4,3)=1; efl(4,3)=1;

x(5,1)= a; y(5,1)=a; efl(5,1)=2;  %five element
x(5,2)= a; y(5,2)=1; efl(5,2)=1;
x(5,3)=-1; y(5,3)=1; efl(5,3)=1;

x(6,1)=-1; y(6,1)=a; efl(6,1)=3;  %six element
x(6,2)= a; y(6,2)=a; efl(6,2)=2;
x(6,3)=-1; y(6,3)=1; efl(6,3)=1;

% for i=1:6
%     for j=1:3
%         if efl(i,j)==2
%             rad=sqrt(x(i,j)^2+y(i,j)^2);
%             x(i,j)=x(i,j)*rad;   y(i,j)=y(i,j)*rad;
%         end
%     end
% end

if ndiv>0
    for i=1:ndiv
        nm=0; %count the new element arising by each refinment loop
        %four element will be generated in each pass
        for j=1:ne  % loop over current element
            %assign vertex nodes to sub-elements
            %these will become the 'new' element
            x(j,4)=0.5*(x(j,1)+x(j,2)); y(j,4)=0.5*(y(j,1)+y(j,2));
            x(j,5)=0.5*(x(j,2)+x(j,3)); y(j,5)=0.5*(y(j,2)+y(j,3));
            x(j,6)=0.5*(x(j,3)+x(j,1)); y(j,6)=0.5*(y(j,3)+y(j,1));
            
            efl(j,4)=0;  efl(j,5)=0;  efl(j,6)=0;
            
            if (efl(j,1)==1 && efl(j,2)==1) efl(j,4)=1; end
            if (efl(j,2)==1 && efl(j,3)==1) efl(j,5)=1; end
            if (efl(j,3)==1 && efl(j,1)==1) efl(j,6)=1; end
            
            if (efl(j,1)==2 && efl(j,2)==2) efl(j,4)=2; end
            if (efl(j,2)==2 && efl(j,3)==2) efl(j,5)=2; end
            if (efl(j,3)==2 && efl(j,1)==2) efl(j,6)=2; end
            
            if (efl(j,1)==3 && efl(j,3)==2) efl(j,6)=2; end
            
            if (efl(j,1)==3 && efl(j,2)==2) efl(j,4)=2; end
            
            if (efl(j,1)==3 && efl(j,2)==1) efl(j,4)=1; end
            
            if (efl(j,1)==3 && efl(j,3)==1) efl(j,6)=1; end
            
            nm=nm+1;   %first sub element
            
            xn(nm,1)=x(j,1); yn(nm,1)=y(j,1); efln(nm,1)=efl(j,1);
            xn(nm,2)=x(j,4); yn(nm,2)=y(j,4); efln(nm,2)=efl(j,4);
            xn(nm,3)=x(j,6); yn(nm,3)=y(j,6); efln(nm,3)=efl(j,6);
            
            nm=nm+1;    %second sub-element
            
            xn(nm,1)=x(j,4); yn(nm,1)=y(j,4); efln(nm,1)=efl(j,4);
            xn(nm,2)=x(j,2); yn(nm,2)=y(j,2); efln(nm,2)=efl(j,2);
            xn(nm,3)=x(j,5); yn(nm,3)=y(j,5); efln(nm,3)=efl(j,5);
            
            
            nm=nm+1;   %third sub-elemen
            
            xn(nm,1)=x(j,6); yn(nm,1)=y(j,6); efln(nm,1)=efl(j,6);
            xn(nm,2)=x(j,5); yn(nm,2)=y(j,5); efln(nm,2)=efl(j,5);
            xn(nm,3)=x(j,3); yn(nm,3)=y(j,3); efln(nm,3)=efl(j,3);
            
            
            nm=nm+1;   %fourth sub-elemen
            
            xn(nm,1)=x(j,4); yn(nm,1)=y(j,4); efln(nm,1)=efl(j,4);
            xn(nm,2)=x(j,5); yn(nm,2)=y(j,5); efln(nm,2)=efl(j,5);
            xn(nm,3)=x(j,6); yn(nm,3)=y(j,6); efln(nm,3)=efl(j,6);
            
        end  % end of loop over current element
        
        ne=4*ne;  % number of element has increased
        % by a factor of four
        
        for k=1:ne  % relable the new points and put them in the master list
            % project boundary nodes onto the circle
            for l=1:3
                x(k,l)=xn(k,l);   y(k,l)=yn(k,l);   efl(k,l)=efln(k,l);
                
                %                if (efl(k,l)==2 || efl(k,l)==3)
                %                    rad=sqrt(x(k,l)^2+y(k,l)^2);
                %                    x(k,l)=x(k,l)/rad;   y(k,l)=y(k,l)/rad;
                %                end
            end
        end
    end % end do of refinment loop
end  % end if of refinment loop

% 6 nodes of the first element are entered manually

p(1,1)=x(1,1); p(1,2)=y(1,1); gfl(1,1)=efl(1,1);
p(2,1)=x(1,2); p(2,2)=y(1,2); gfl(2,1)=efl(1,2);
p(3,1)=x(1,3); p(3,2)=y(1,3); gfl(3,1)=efl(1,3);

c(1,1)=1; c(1,2)=2; c(1,3)=3;
eps=0.000001; ng=3;

for i=2:ne
    for j=1:3
        Iflag=0;
        for k=1:ng
            if (abs(x(i,j)-p(k,1))<eps)
                if (abs(y(i,j)-p(k,2))<eps)
                    Iflag=1;
                    c(i,j)=k;
                end
            end
        end
        if (Iflag==0)
            ng=ng+1;
            p(ng,1)=x(i,j);
            p(ng,2)=y(i,j);
            gfl(ng,1)=efl(i,j);
            c(i,j)=ng;
        end
    end
end
%  fo

% 6 nodes of the first element are entered manually


for i=1:ne
    xp(1)=x(i,1); xp(2)=x(i,2); xp(3)=x(i,3); xp(4)=x(i,1);
    yp(1)=y(i,1); yp(2)=y(i,2); yp(3)=y(i,3); yp(4)=y(i,1);
end

for i=1:ne
    xp(1)=p(c(i,1),1); yp(1)=p(c(i,1),2);
    xp(2)=p(c(i,2),1); yp(2)=p(c(i,2),2);
    xp(3)=p(c(i,3),1); yp(3)=p(c(i,3),2);
    xp(4)=p(c(i,1),1); yp(4)=p(c(i,1),2);
    plot(xp,yp,'r-o');hold on
end
% % trimesh(c,p(:,1),p(:,2),zeros(ng,1))
% hold on
% 
% a=find(gfl(:)==1 | gfl(:)==2 | gfl(:)==3);
% b=find(gfl(:)==0);
% % b=find(efl(:)==0);
% 
% Nb = length(p(a,1));
% Ni = length(p(b,2));
% 
% x=[p(a,1);p(b,1)];
% y=[p(a,2);p(b,2)];
% % plot(x,y,'o')
% plot(x(1:Nb),y(1:Nb),'b*',x(Nb+1:end),y(Nb+1:end),'ro')

end