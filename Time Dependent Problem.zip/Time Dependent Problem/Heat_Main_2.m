% ==============================
% u_t = u_xx + f(x,t),
% u(x,0)=g(x)
% u(a,t)=p(t),  u(b,t)=q(t)
% ============================
clear all
clc
tic
format shorte
u = @(x,t) exp(t).*sin(pi.*x);
f = @(x,t) (1+pi.^2).*exp(t).*sin(pi.*x);
% u = @(x,t) exp(x+t);
% f = @(x,t) 0.*exp(x+t);
a = -2;
b = 2;
Mt = 2000; % Time Step
T = 1;
dt = T/Mt;
N = 320;
h = (b-a)/N;
x=a:h:b;
%=========================================
D = (1/h).*gallery('tridiag',N+1,-1,2,-1);
D(1,1) = 1/h;  D(N+1,N+1) = 1/h;
%=========================================
M = (h/6).*gallery('tridiag',N+1,+1,4,+1);
M(1,1) = h/3;  M(N+1,N+1) = h/3;
%=========================================
C = zeros(Mt+1,length(x));
C(1,:) = u(x,0)';
A = M+(dt/2).*D;
B = M-(dt/2).*D;
%=========================================
I = eye(size(A));
A(1,:)   = I(1,:); 
A(end,:) = I(end,:);

for n=0:Mt-1
    t = (n+1)*dt
    F = B*C(n+1,:)' + dt*M*f(x,(n+0.5)*dt)';
    F(1)   = u(a,t);
    F(end) = u(b,t);
    C(n+2,:) = A\F;
end
clc
Q = (C(end,:)-u(x,T));
norm(Q,inf)
% figure
subplot(2,1,1)
plot(x,C(end,:),'o',x,u(x,T))
toc

[X,T] = meshgrid(x,0:dt:T);
subplot(2,1,2)
mesh(X,T,C)
subplot(2,2,1)
pcolor(X,T,C), shading interp
subplot(2,2,2)
contour(X,T,C)


% pause
% clc
% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [U,S,V] = svd(C');
% tic
% U=U(:,1:10);
% Ah=U'*A*U;
% Bh=U'*B*U;
% Mh=U'*M*U;
% Y = u(x,0)';
% for n=1:Mt
%     n*dt
%     F = B*Y + dt*M*(f(x,n*dt)');
%     F(1) = u(a,n*dt);
%     F(end) = u(b,n*dt);
%     F = U'*F;
%     Y = Ah\F;
%     Y = U*Y;
% end
% Q = norm(Y-u(x,T)',inf)
% toc